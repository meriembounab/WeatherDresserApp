module.exports = {
    db: {
      uri: 'mongodb://<cosmosdb_name>:xAceMy060oVfHcdf4040QGHk1YfJuwxLzrpvN1SYA0miFZLbhLiM05U91oLFPfjdhmDQm8vnbIRa9wjf0xxwNA==@weatherdresser.documents.azure.com:10250/mean?ssl=true&sslverifycertificate=false'
    }
  };